// Volleyball stream scoreboard: zero-dependency Node server.
// Run:  node server.js     (optional: PORT=3000 PIN=1234 node server.js)
//
//   /overlay  -> add as a Browser Source in OBS / Streamlabs (transparent background)
//   /control  -> open on the second phone to run the scoreboard

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = Number(process.env.PORT) || 3000;
const PIN = process.env.PIN || '';
const PUBLIC_DIR = path.join(__dirname, 'public');

const clone = (o) => JSON.parse(JSON.stringify(o));

const fresh = () => ({
  visible: true,
  title: '',
  bestOf: 5,
  teams: [
    { name: 'HOME', color: '#2563eb', points: 0, sets: 0, timeouts: 2 },
    { name: 'AWAY', color: '#dc2626', points: 0, sets: 0, timeouts: 2 },
  ],
  serving: null, // 0, 1 or null
  history: [], // finished sets as [teamA points, teamB points]
});

let state = fresh();
const undoStack = [];

// Keep the match across restarts (cloud hosts restart apps now and then).
const STATE_FILE = process.env.STATE_FILE || path.join(__dirname, 'state.json');
try {
  const saved = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
  const ok =
    saved &&
    Array.isArray(saved.teams) &&
    saved.teams.length === 2 &&
    saved.teams.every((t) => typeof t.name === 'string' && Number.isFinite(t.points) && Number.isFinite(t.sets)) &&
    Array.isArray(saved.history);
  if (ok) state = { ...fresh(), ...saved };
} catch {
  /* no saved match yet */
}
let saveTimer;
function saveSoon() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => fs.writeFile(STATE_FILE, JSON.stringify(state), () => {}), 300);
}

// Values the clients need but shouldn't have to work out themselves.
function derive(s) {
  const setNo = s.history.length + 1;
  const target = setNo >= s.bestOf ? 15 : 25; // deciding set goes to 15
  const [a, b] = [s.teams[0].points, s.teams[1].points];
  const setWinner = Math.max(a, b) >= target && Math.abs(a - b) >= 2 ? (a > b ? 0 : 1) : null;
  const setsToWin = Math.ceil(s.bestOf / 2);
  const matchWinner = s.teams[0].sets >= setsToWin ? 0 : s.teams[1].sets >= setsToWin ? 1 : null;
  return { setNo, target, setWinner, setsToWin, matchWinner };
}

const clampInt = (v, min, max) => Math.min(max, Math.max(min, Math.trunc(Number(v)) || 0));
const cleanText = (v, n) => String(v ?? '').replace(/[\u0000-\u001f]/g, '').slice(0, n);
const validColor = (v) => (/^#[0-9a-fA-F]{6}$/.test(v) ? v : null);

// Returns true if the state changed.
function apply(a) {
  const t = a.team === 0 || a.team === 1 ? a.team : null;
  const team = t === null ? null : state.teams[t];

  switch (a.type) {
    case 'point': {
      if (!team) return false;
      const delta = a.delta < 0 ? -1 : 1;
      team.points = clampInt(team.points + delta, 0, 99);
      if (delta > 0) state.serving = t; // rally winner serves
      return true;
    }
    case 'setPoints':
      if (!team) return false;
      team.points = clampInt(a.value, 0, 99);
      return true;
    case 'serve':
      if (t === null) return false;
      state.serving = state.serving === t ? null : t;
      return true;
    case 'timeout':
      if (!team) return false;
      team.timeouts = clampInt(team.timeouts + (a.delta < 0 ? -1 : 1), 0, 2);
      return true;
    case 'sets':
      if (!team) return false;
      team.sets = clampInt(team.sets + (a.delta < 0 ? -1 : 1), 0, 3);
      return true;
    case 'endSet': {
      const [p0, p1] = [state.teams[0].points, state.teams[1].points];
      if (p0 === p1) return false; // nothing to record on a tie
      state.history.push([p0, p1]);
      state.teams[p0 > p1 ? 0 : 1].sets += 1;
      state.teams.forEach((x) => {
        x.points = 0;
        x.timeouts = 2;
      });
      state.serving = null;
      return true;
    }
    case 'swap':
      state.teams.reverse();
      state.history = state.history.map(([x, y]) => [y, x]);
      if (state.serving !== null) state.serving = 1 - state.serving;
      return true;
    case 'name':
      if (!team) return false;
      team.name = cleanText(a.value, 24) || (t === 0 ? 'HOME' : 'AWAY');
      return true;
    case 'color': {
      const c = validColor(a.value);
      if (!team || !c) return false;
      team.color = c;
      return true;
    }
    case 'title':
      state.title = cleanText(a.value, 40);
      return true;
    case 'bestOf':
      state.bestOf = Number(a.value) === 3 ? 3 : 5;
      return true;
    case 'visible':
      state.visible = a.value === true || a.value === 'true';
      return true;
    case 'newMatch': {
      const keep = state;
      state = fresh();
      state.title = keep.title;
      state.bestOf = keep.bestOf;
      state.visible = keep.visible;
      state.teams.forEach((x, i) => {
        x.name = keep.teams[i].name;
        x.color = keep.teams[i].color;
      });
      return true;
    }
    default:
      return false;
  }
}

function handleAction(a) {
  if (a.type === 'undo') {
    const prev = undoStack.pop();
    if (!prev) return;
    state = prev;
    return broadcast();
  }
  const before = clone(state);
  if (apply(a)) {
    // Cosmetic changes (visibility, text, color) don't need an undo slot.
    if (!['visible', 'name', 'color', 'title', 'bestOf'].includes(a.type)) {
      undoStack.push(before);
      if (undoStack.length > 50) undoStack.shift();
    }
    broadcast();
  }
}

// ---- live updates (Server-Sent Events) ----
const clients = new Set();
const payload = () => JSON.stringify({ state, derived: derive(state), canUndo: undoStack.length > 0 });

function broadcast() {
  saveSoon();
  const msg = `data: ${payload()}\n\n`;
  for (const res of clients) res.write(msg);
}

setInterval(() => {
  for (const res of clients) res.write(': ping\n\n'); // keeps connections open through proxies
}, 20000);

// ---- http ----
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css' };

function serveFile(res, name) {
  fs.readFile(path.join(PUBLIC_DIR, name), (err, data) => {
    if (err) {
      res.writeHead(404);
      return res.end('Not found');
    }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(name)] || 'text/plain', 'Cache-Control': 'no-store' });
    res.end(data);
  });
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');

  if (req.method === 'GET') {
    if (url.pathname === '/') {
      res.writeHead(302, { Location: '/control' });
      return res.end();
    }
    if (url.pathname === '/healthz') {
      res.writeHead(200);
      return res.end('ok');
    }
    if (url.pathname === '/overlay') return serveFile(res, 'overlay.html');
    if (url.pathname === '/control') return serveFile(res, 'control.html');
    if (url.pathname === '/api/config') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ pinRequired: Boolean(PIN) }));
    }
    if (url.pathname === '/api/state') {
      res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
      return res.end(payload());
    }
    if (url.pathname === '/events') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-store',
        Connection: 'keep-alive',
        'X-Accel-Buffering': 'no',
      });
      res.write(`retry: 1000\n\ndata: ${payload()}\n\n`);
      clients.add(res);
      req.on('close', () => clients.delete(res));
      return;
    }
  }

  if (req.method === 'POST' && url.pathname === '/api/action') {
    if (PIN && req.headers['x-pin'] !== PIN) {
      res.writeHead(401);
      return res.end('Wrong PIN');
    }
    let body = '';
    req.on('data', (c) => {
      body += c;
      if (body.length > 10_000) req.destroy();
    });
    req.on('end', () => {
      try {
        handleAction(JSON.parse(body));
        res.writeHead(204);
        res.end();
      } catch {
        res.writeHead(400);
        res.end('Bad request');
      }
    });
    return;
  }

  res.writeHead(404);
  res.end('Not found');
});

server.listen(PORT, '0.0.0.0', () => {
  const ips = Object.values(os.networkInterfaces())
    .flat()
    .filter((i) => i && i.family === 'IPv4' && !i.internal)
    .map((i) => i.address);
  console.log('\nVolleyball stream scoreboard is running\n');
  console.log(`  OBS / Streamlabs Browser Source:  http://localhost:${PORT}/overlay`);
  ips.forEach((ip) => console.log(`  Phone controller (same Wi-Fi):    http://${ip}:${PORT}/control`));
  if (PIN) console.log('\n  Controller PIN is enabled.');
  else console.log('\n  No PIN set: anyone who can reach this address can change the score. Use PIN=1234 when hosting online.');
  console.log('');
});
