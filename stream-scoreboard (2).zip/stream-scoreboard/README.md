# Volleyball Stream Scoreboard

A live volleyball scoreboard for YouTube streams. One device runs the scoreboard and shows it on your stream. A second phone controls it.

- **Overlay** (`/overlay`): the scoreboard graphic. Transparent background, added to your stream as a Browser Source.
- **Controller** (`/control`): a big-button page for the second phone.

It tracks points, sets won, who is serving, timeouts (2 per set), previous set scores, win-by-2 rules (sets go to 25, the deciding set goes to 15), best of 3 or 5, and has an Undo button.

## Phone-only setup (no computer)

Stream from one phone and score from another, with the scoreboard hosted online so no computer is involved.

**1. Put the scoreboard online (one time, about 10 minutes).** It needs a host that runs Node or Docker. This folder includes a `Dockerfile` and a `render.yaml` for [Render](https://render.com), which has a free plan (check its current limits):

1. Put this folder in a GitHub repository.
2. On Render choose **New > Blueprint**, pick the repository, and type a **PIN** when asked (for example `4821`). The PIN stops other people from changing your score.
3. When it finishes you get an address like `https://volleyball-scoreboard.onrender.com`.

Free plans often put the app to sleep when idle, so the first load can take up to a minute. Open your controller link a few minutes before you go live.

**2. Add the overlay to your phone streaming app.** It needs an app that can show a web page over the video:

- **Streamlabs mobile app:** Scenes, create a scene, add a layer, choose **Add a URL**, paste `https://YOUR-ADDRESS/overlay`, then drag it to the top or bottom. Make the scene in both orientations if you switch between portrait and landscape.
- **CameraFi Live:** tap the widget icon, open the **Web** tab, paste the overlay address into a URL slot, and turn it ON when you go live.

The YouTube app's own "Go live" has no overlay option, so it can't show the scoreboard. The overlay shrinks to fit small layers automatically.

**3. Score from the second phone.** Open `https://YOUR-ADDRESS/control`, enter your PIN, and add it to the home screen. It works on any connection, so the scorekeeper can be anywhere.

## Setup (computer streaming)

1. Install [Node.js](https://nodejs.org) (version 16 or newer) on the computer you stream from.
2. In this folder, run:

   ```
   node server.js
   ```

   It prints two addresses. Keep the window open while you stream.

3. **Add the overlay to your stream** (OBS Studio or Streamlabs Desktop):
   - Add a source, choose **Browser**.
   - URL: `http://localhost:3000/overlay`
   - Width 1920, Height 1080.
   - Stream to YouTube the way you normally do. The scoreboard shows up in the video.

4. **Control it from the second phone:**
   - Connect the phone to the same Wi-Fi as the computer.
   - Open the "Phone controller" address the server printed, for example `http://192.168.1.25:3000/control`.
   - Add it to your home screen for a full-screen app feel.

## Using the controller

| Button | What it does |
| --- | --- |
| **+1 point** | Adds a point and gives that team the serve (rally winner serves). |
| **−1** | Fixes a mistake. Does not change the serve. |
| **Serving** | Sets or clears the serve indicator manually. |
| **Timeout** | Uses one of the team's 2 timeouts for the set. |
| **End set** | Records the set score, adds a set win, and resets points and timeouts. It turns yellow when a team has won the set (25 or 15, win by 2). |
| **Undo** | Steps back through your last 50 changes. |
| **Swap sides** | Swaps teams between the two rows, for between sets. |
| **Overlay ON/OFF** | Fades the scoreboard in or out on stream. |
| **Format** | Best of 3 or best of 5. |
| **New match** | Resets everything but keeps names, colors and title. |

Team names, colors and the match title can be edited right on the controller and show up on stream as you type.

## Overlay position and size

Add options to the overlay URL:

- `?pos=bottom` puts it at the bottom of the screen (default is the top).
- `?align=right` or `?align=center` moves it horizontally (default is left).
- `?zoom=1.5` makes it bigger.

Combine them like `http://localhost:3000/overlay?pos=bottom&align=center&zoom=1.3`.

## Controlling from outside your Wi-Fi

If the scorekeeper is at a different place from the computer (or on mobile data), you need a public address and a PIN:

1. Start with a PIN: `PIN=4821 node server.js` (on Windows PowerShell: `$env:PIN="4821"; node server.js`).
2. Expose the port with a tunnel such as [Cloudflare Tunnel](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/) or [ngrok](https://ngrok.com), then open `<tunnel address>/control` on the phone and enter the PIN.

Anyone who has the address can see the overlay, but only someone with the PIN can change the score.

## Streaming from a phone only

A phone streaming app generally can't load a Browser Source, so the scoreboard can't be added directly. Options:

- Stream from a computer using OBS or Streamlabs (recommended).
- Use a phone streaming app that supports web overlays or browser sources, then point it at the overlay URL.

## Troubleshooting

- **Phone can't open the controller:** check that both devices are on the same Wi-Fi, and allow Node.js through the computer's firewall when prompted. Guest Wi-Fi networks often block device-to-device traffic.
- **Overlay is blank in OBS:** that's normal when the overlay is hidden. Tap "Overlay: ON" on the controller. Right-click the source and choose Refresh if it still doesn't show.
- **Different port:** `PORT=8080 node server.js`.
- The match is saved to `state.json` next to `server.js`, so a restart keeps the score. Delete that file, or tap **New match**, to start fresh. Some free hosts erase files when they restart the app, which also resets the match.
