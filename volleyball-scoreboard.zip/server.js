// Tiny scoreboard relay: no dependencies. Run: node server.js
const http=require('http'),fs=require('fs'),path=require('path');
const PORT=process.env.PORT||3000, rooms=new Map();
const room=id=>{if(!rooms.has(id))rooms.set(id,{state:null,clients:new Set()});return rooms.get(id)};
const files={'/':['scoreboard.html','text/html; charset=utf-8'],'/manifest.json':['manifest.json','application/manifest+json'],'/icon.svg':['icon.svg','image/svg+xml']};
http.createServer((req,res)=>{
  const u=new URL(req.url,'http://x');
  if(u.pathname==='/api/time'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({t:Date.now()}))}
  const m=u.pathname.match(/^\/api\/([\w-]{3,40})(\/stream)?$/);
  if(m){
    const r=room(m[1]);
    if(m[2]){
      res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});
      if(r.state)res.write('data: '+r.state+'\n\n');
      r.clients.add(res);
      const ka=setInterval(()=>res.write(': ping\n\n'),25000);
      req.on('close',()=>{clearInterval(ka);r.clients.delete(res)});
      return;
    }
    if(req.method==='POST'){
      let b='';
      req.on('data',d=>{b+=d;if(b.length>10000)req.destroy()});
      req.on('end',()=>{try{JSON.parse(b)}catch(e){res.writeHead(400);return res.end()}
        const key=String(req.headers['x-key']||'');
        if(!key||(r.key&&r.key!==key)){res.writeHead(403);return res.end()}
        r.key=key;
        r.state=b;r.clients.forEach(c=>c.write('data: '+b+'\n\n'));res.writeHead(204);res.end()});
      return;
    }
    res.writeHead(405);return res.end();
  }
  const f=files[u.pathname];
  if(!f){res.writeHead(404);return res.end('Not found')}
  fs.readFile(path.join(__dirname,f[0]),(e,d)=>{if(e){res.writeHead(500);return res.end()}
    res.writeHead(200,{'Content-Type':f[1],'Cache-Control':'no-cache'});res.end(d)});
}).listen(PORT,()=>console.log('Scoreboard running on port '+PORT));
